<?php
include 'pharStub.php';
 __HALT_COMPILER(); ?>
