<?php


echo "Inside PHAR stub. Bootstrapping ...";
include "pharFile.php";



?>