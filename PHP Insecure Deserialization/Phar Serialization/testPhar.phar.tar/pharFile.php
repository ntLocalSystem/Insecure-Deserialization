<?php

echo "Executing PHAR file...";

?>